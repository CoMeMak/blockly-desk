function dispatchAndManageTask(task) { 
  i = 0;
  return new Promise(resolve => {
    var interval = setInterval(() => {
      if(i == 3)
	  {
		resolve(task);
	  }
	  else
	  {
		i++;
	  }
	
    }, 2000);
  });
}

async function executeTaskAsync(task) {
  var x = await dispatchAndManageTask(task);
  console.log(x); // 10
}

function executeTask(task_name)
{
	executeTaskAsync(task_name);
}