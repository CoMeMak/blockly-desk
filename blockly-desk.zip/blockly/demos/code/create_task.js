function createTask(taskName,appId,params) {
	return new Promise(resolve => {
		
		if($("span:contains('" + taskName + "')").length > 0)
		{
			console.log("Task " + taskName + " exists.");	
			resolve(20);
		}
		else
		{
			var delay = 1000;
			var taskId = taskName.toLowerCase();
			
			var resolvePromise = function()
			{
				resolve(20);				
			}
			
			var setAppParams = function()
			{
				var appParams = [{"path":{"id":taskId,"indices":[0,0]},"parameter":{"acceleration":0.15,"cartesian_impedance":{"access":["parent","parameter","cartesian_impedance"]},"joint_impedance":{"access":["parent","parameter","joint_impedance"]},"offset":{"x":params.x,"y":params.y,"z":params.z},"safety":{"access":["parent","parameter","safety"]},"speed":{"access":["parent","parameter","speed"]},"velocity":0.3,"world":true}}];
					
				$.ajax({
					type: 'PUT',
					url: '/desk/api/timelines',
					contentType: 'application/x-www-form-urlencoded',
					data: {
						parameters: JSON.stringify(appParams)
					}, 
				}).done(function () {
					console.log('Added parameters to app');
					setTimeout(resolvePromise, delay);
				}).fail(function (msg) {
					console.log(msg);
				});	
			}
			
			var addApp = function()
			{
				$.post( "/desk/api/timelines/" + taskId + "/0/0", { id: appId } ).done(function( data ) 
				{
					console.log("Created app: " + appId);
					setTimeout(setAppParams, delay);				
				});
			}
			
			var loadTask = function()
			{
				$("span:contains('" + taskName + "')").trigger("click");
				setTimeout(addApp, delay);
			};
			
			$.post( "/desk/api/timelines", { name: taskName } ).done(function( data ) 
			{
				console.log("Created task: " + taskName);
				setTimeout(loadTask, delay);
			});
		}
	});
}

/*
function executeTask(taskName) {
	return new Promise(resolve => {
		var taskId = taskName.toLowerCase();
		$.post( "/desk/api/execution", { id: taskId } ).done(function( data ) 
		{
			console.log("Executed task: " + taskName);
			resolve(20);
		});			
	});
}
*/

function executeTask(task) {
	return new Promise(resolve => {
		task = task.trim();
		var state = "idle";
		var cb = -1;
		var PLAY_BTN = "i.fi-play"; /* previously "div.fi-play" */
		var STOP_BTN = "i.fi-stop"; /* previously "div.fi-stop" */ 

		cb = setInterval(function(){
			if($(PLAY_BTN).length == 1 && state == "idle")
			{
				if(!$(".timeline-label")[0].textContent.includes(task))
				{
					$("span:contains('" + task + "')").trigger("click");
				}
				state = "init";
			}
			else if( $(PLAY_BTN).length == 1 && state == "init" && $(".timeline-label")[0].textContent.includes(task))
			{
				$(PLAY_BTN).trigger("click");
				state = "waitforstop";
				console.log(task + " task started.");
			}
			else if( $(STOP_BTN).length == 1 && state == "waitforstop")
			{
				state = "running";
			}
			else if( $(STOP_BTN).length == 1 && state == "running")
			{
				console.log(task + " still running...");
			}
			else if( $(PLAY_BTN).length == 1 && state == "running")
			{
				state = "finished";
				console.log(task + " task finished.");
			}
			else if( state == "finished" )
			{
				clearInterval(cb);
				resolve(20);				
			}
		},200);
	});
}



const p1 = await createTask("AA1","move_relative",{"x":0.021,"y":0.022,"z":0.023});
const p2 = await createTask("AA2","move_relative",{"x":-0.021,"y":-0.022,"z":-0.023});

for(i=0;i<5;i++)
{
	const p3 = await executeTask("AA1");
}

for(i=0;i<5;i++)
{
	const p4 = await executeTask("AA2");
}
/*
$.post( "/desk/api/execution", { id: "task336" } ).done(function( data ) 
		{
			console.log("Executed task: " + taskName);
		});	
*/